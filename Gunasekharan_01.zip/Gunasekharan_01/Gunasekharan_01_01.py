# Gunasekharan, Jayasurya
# 1002_060_437
# 2023_09_24
# Assignment_01_01

import numpy as np


def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def mse(y_true, y_pred):
    # Mean squared error calculation
    return np.mean((y_true - y_pred) ** 2)

def forward_pass(X, weights):
    activations = [X]
    for i in range(len(weights)):
        input_data = np.vstack((np.ones(X.shape[1]), activations[-1]))
        z = np.dot(weights[i], input_data)
        activation = sigmoid(z)
        activations.append(activation)
    return activations


def multi_layer_nn(X_train, Y_train, X_test, Y_test, layers, alpha, epochs, h, seed):
    weights = []
    error_history = []
    actual_outputs = []
    np.random.seed(seed)

    # Initialize weights for the input layer
    input_dim = X_train.shape[0]
    hidden_layers = layers
    output_dim = Y_train.shape[0]

    for layer_index in range(len(hidden_layers) + 1):
        if layer_index == 0:
            # Input layer to the first hidden layer
            num_nodes_in_layer = hidden_layers[layer_index]
            weights.append(np.random.randn(num_nodes_in_layer, input_dim + 1))
        elif layer_index == len(hidden_layers):
            # Last hidden layer to the output layer
            num_nodes_in_layer = output_dim
            weights.append(np.random.randn(output_dim, hidden_layers[-1] + 1))
        else:
            # Hidden layers
            num_nodes_in_layer = hidden_layers[layer_index]
            weights.append(np.random.randn(num_nodes_in_layer,
                           hidden_layers[layer_index - 1] + 1))

    for epoch in range(epochs):
        mse_error = 0

        actual_outputs.append(forward_pass(X_test, weights)[-1])
        mse_error = mse(Y_test, forward_pass(X_test, weights)[-1])

        # Update weights using gradient descent with centered difference approximation
        for i in range(len(weights)):
            original_weights = weights[i].copy()  # Make a copy of the original weights
            for j in range(weights[i].shape[0]):
                for k in range(weights[i].shape[1]):
                    # Calculate gradient using centered difference approximation
                    weights[i][j, k] += h
                    error_plus_h = mse(Y_train, forward_pass(X_train, weights)[-1])
                    weights[i][j, k] -= 2 * h
                    error_minus_h = mse(Y_train, forward_pass(X_train, weights)[-1])
                    gradient = (error_plus_h - error_minus_h) / (2 * h)

                    # Update weight using gradient descent
                    weights[i][j, k] = original_weights[j, k] - alpha * gradient

        error_history.append(mse_error)

    return weights, error_history, np.array(actual_outputs)